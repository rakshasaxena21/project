package com.cg.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;
import com.cg.asset.util.DbUtil;

public class UserDao  implements IUserDao {
	private static final String GET_QUERY="select userid,username,userpassword,usertype from user_master where userid=?";

	@Override
	public User compare(String userid) throws UserException {
	    User user=null;
	    Connection conn=null;
	    PreparedStatement pstm=null;
	    try {
	         conn=DbUtil.getConnection();
	         pstm=conn.prepareStatement(GET_QUERY);
	        pstm.setString(1,userid);
	        ResultSet resOne=pstm.executeQuery();
	        while(resOne.next())
	        {
	             user=new User();
	             user.setUserid(resOne.getString("userid"));
	             user.setUsername(resOne.getString("username"));
	             user.setUserpassword(resOne.getString("userpassword"));
	             user.setUsertype(resOne.getString("usertype"));
	             System.out.println("in dao" +user.getUsertype());

	             
	        }

	    }   
	    catch(SQLException | NamingException e )
	    {
	    	throw new UserException();
	    }
	    finally
	    {
	        try{
	            pstm.close();
	            conn.close();
	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	    }
	    return user;
	} 
}
