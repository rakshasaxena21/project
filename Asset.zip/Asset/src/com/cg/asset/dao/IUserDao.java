package com.cg.asset.dao;

import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;

public interface IUserDao {
	User compare(String userid) throws UserException;

}
