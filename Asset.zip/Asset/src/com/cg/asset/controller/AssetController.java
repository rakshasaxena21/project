package com.cg.asset.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.asset.dto.User;
import com.cg.asset.service.IUserService;
import com.cg.asset.service.UserService;
import com.cg.asset.util.DbUtil;



@WebServlet("*.mvc")
public class AssetController extends HttpServlet 
{
	  private static final long serialVersionUID = 1L;
IUserService service;
User user;

@Override public void init() throws ServletException 
{ 
	service=new UserService();
}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{ 
	String action=request.getServletPath();

switch (action) {
case "/form.mvc":
	System.out.println("Started...!!!!!");
   String id=request.getParameter("id");
   String pass=request.getParameter("password");
   Connection conn;
	try {
		conn = DbUtil.getConnection();
		 PreparedStatement pst=conn.prepareStatement("Select usertype from  user_master where userid = ? and userpassword = ? "); 
		    pst.setString(1,id); 
		    pst.setString(2,pass);
		  
		    ResultSet rst=pst.executeQuery(); 
		    while(rst.next()) 
		    { 
		    String type=rst.getString("usertype"); 
		    System.out.println("hun ki kara!!!!");
		    System.out.println("user type="+type); 
		    if(type.equals("admin")) 
		    { 
		    	  System.out.println("Started...!!!!!");
		    System.out.println(type); 
		    request.setAttribute("usertype", type);
		    RequestDispatcher rd = request.getRequestDispatcher("Admin.jsp");
		    rd.forward(request, response);
		    } 
		    else if("manager".equals(type)) 
		    { 
		    System.out.println(type); 
		    request.setAttribute("usertype", type);
		    RequestDispatcher rd = request.getRequestDispatcher("Manager.jsp");
		    rd.forward(request, response);
		    } 
		   
		    }
	} catch (NamingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
 
   break;

default:
   break;
}
}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
	doGet(request, response); 
	}

}



