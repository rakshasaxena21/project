package com.cg.asset.service;

import com.cg.asset.dao.IUserDao;
import com.cg.asset.dao.UserDao;
import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;

public class UserService implements IUserService {
	IUserDao dao=new UserDao();

	@Override
	public User compare(String userid) throws UserException {
		// TODO Auto-generated method stub
		return dao.compare(userid);
	}

	
}
