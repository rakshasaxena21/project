package com.cg.asset.service;

import com.cg.asset.dto.User;
import com.cg.asset.exception.UserException;

public interface IUserService {
	User compare(String userid) throws UserException;

}
